from .regex import *

__doc__ = regex.__doc__
if hasattr(regex, "__all__"):
    __all__ = regex.__all__